import numpy as np
from flask import Flask, request, jsonify, render_template
from joblib import load
from sklearn import preprocessing

from tensorflow.keras.models import load_model

app = Flask(__name__)

model = load_model("diabetes.h5")

@app.route('/') #default route
def home():
    return render_template('index.html')

@app.route('/y_predict',methods=['POST'])
def y_predict():
    
    Pregnancies = request.form["Pregnancies"]
    Glucose = request.form["Glucose"]
    BloodPressure = request.form["BloodPressure"]
    SkinThickness = request.form["SkinThickness"]
    Insulin = request.form["Insulin"]
   
    BMI = request.form["BMI"]
    DiabetesPedigreeFunction = request.form["DiabetesPedigreeFunction"]
    Age = request.form["Age"]
    
    total = [[int(Pregnancies),int(Glucose),int(BloodPressure),int(SkinThickness),int(Insulin),float(BMI),float(DiabetesPedigreeFunction),int(Age)]]
    #print(t)
    #prediction = model.predict(sc.transform(total))
    pred= preprocessing.StandardScaler().fit(total)
    
    if(pred == 0):
        output = "Negative Diabetes"
        print("Negative Diabetes")
    else:
        output = "Positive Diabetes"
        print("Positive Diabetes")

    return render_template('index.html', prediction_text='Result: {}'.format(output))

if __name__ == "__main__":
    app.run(port=8086,debug=False)
